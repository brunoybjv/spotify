# import pytest

# from spotdl.providers.lyrics.musixmatch import MusixMatch


# @pytest.mark.vcr()
# def test_get_musixmatch_lyrics():
#     musixmatch = MusixMatch()

#     assert musixmatch.get_lyrics("Mortals", ["Warriyo"]) is not None
