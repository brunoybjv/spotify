"""
Download module that holds the downloader and progress handler modules.
"""
